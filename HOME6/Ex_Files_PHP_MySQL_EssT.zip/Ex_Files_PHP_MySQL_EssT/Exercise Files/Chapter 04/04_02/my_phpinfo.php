<?php 

	phpinfo();
	
?>

